const sortProducts = () => {
    const select = document.getElementById('sort');
    const products = document.querySelectorAll('.product');
    const sortedProducts = Array.from(products);
    const originalProducts = Array.from(products); // Copia de los productos originales
    
    sortedProducts.sort((a, b) => {
      const aPrice = parseFloat(a.dataset.precio);
      const bPrice = parseFloat(b.dataset.precio);
      if (select.value === 'mayor') {
        return bPrice - aPrice;
      } else if (select.value === 'menor') {
        return aPrice - bPrice;
      } else  { // Nuevo caso para restaurar el orden original
        const indexA = originalProducts.indexOf(a);
        const indexB = originalProducts.indexOf(b);
        return indexA - indexB;
      }
    });
    
    const productContainer = document.querySelector('.product-container');
    productContainer.innerHTML = '';
    sortedProducts.forEach(product => {
      productContainer.appendChild(product);
    });
  };
  
  const sortSelect = document.getElementById('sort');
  sortSelect.addEventListener('change', sortProducts);